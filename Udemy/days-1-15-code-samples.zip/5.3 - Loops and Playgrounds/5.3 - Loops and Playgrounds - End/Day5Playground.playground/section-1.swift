// Playground - noun: a place where people can play

import UIKit

// Arrays - lists

//var wordArray = [String]()

var wordArray = ["I", "like", "to", "eat", "fruit", "my", "favorite"]

// Code in Playgrounds
wordArray[6]

wordArray.count

wordArray.first
wordArray.last
// ^ Code only in Playgrounds

// Play with remove, add, and insert



// Loops

for word in wordArray {
//    println(word)
    print("\(word), ")
}

for (index, word) in enumerate(wordArray) {
    println("index[\(index)] = \(word)")
}

for var i = 0; i < 10; i++ {
    println(i)
}


for i in 0...10 {
    print(i)
}











