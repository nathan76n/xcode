// Playground - noun: a place where people can play

import UIKit

// if/else conditional statements

var isRaining = true

if isRaining {
    println("It's raining outside!")
    var x = 10
} else {
    println("It's sunny")
}


// Optionals

var businessAddress: String?

println(businessAddress)

businessAddress = "3902 Memorial Drive"

println(businessAddress)

if businessAddress != nil {
    println("Valid address, ship the package!")
}


// Optionals Force Unwrap


// User input
var userInputString = "10a"  // 10.0 // 10

var optionalInt = userInputString.toInt()

if optionalInt != nil {
    // Valid value
    
    var number = optionalInt!
    println("Number: \(number)")
} else {
    println("Invalid input: \(userInputString)")
}























