// Playground - noun: a place where people can play

import UIKit

// Functions

func hello() {
    println("hello")
    var x = 30
    println("\(x)")
}

hello()

// Parameter

func repeatString(text: String, number: Int) {
    for i in 1...number {
        println(text)
    }
}

repeatString("Hello Max!", 3)


// Return values 

func calculateDiscount(price: Double, salePercentage: Double) -> Double {
    return price * (salePercentage / 100.0)
}

calculateDiscount(4.99, 30)