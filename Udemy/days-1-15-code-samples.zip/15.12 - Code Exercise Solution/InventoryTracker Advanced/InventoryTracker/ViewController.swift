//
//  ViewController.swift
//  InventoryTracker
//
//  Created by Paul Solt on 10/28/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

func documentsDirectory() -> String {
    let documentsFolderPath = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0] as String
    return documentsFolderPath
}

func fileInDocumentsDirectory(filename: String) -> String {
    return documentsDirectory().stringByAppendingPathComponent(filename)
}

// Conform to delegate protocol for ImagePicker
class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var itemTextField: UITextField!
    @IBOutlet weak var costTextField: UITextField!
    
    @IBOutlet weak var fileListTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Advanced 1 - Add a gesture recognizer

        // Add a tap gesture to the imageview
        let tapGesture = UITapGestureRecognizer(target: self, action: Selector("handleTapGesture:"))
        imageView.addGestureRecognizer(tapGesture)
    
        // Need to enable for interaction to make gestures work on imageview
        imageView.userInteractionEnabled = true
        
        // Make the image fit aspect ratio
        imageView.contentMode = UIViewContentMode.ScaleAspectFit
    
    }
    
    // Advanced 1 - Add a gesture recognizer
    func handleTapGesture(tapGesture: UITapGestureRecognizer) {
        // open image picker
        
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
//        imagePicker.
        presentViewController(imagePicker, animated: true, completion: nil)
    }
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [NSObject : AnyObject]) {
    
        if let image = info[UIImagePickerControllerOriginalImage] as UIImage? { // use dictionary to look up image
    
            imageView.image = image
        }
        
        // dismiss
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func addButtonPressed(sender: AnyObject) {
        println("add button pressed")
        
        saveDataToDisk()
        
        // update the file list
        let filelist = directoryContents(documentsDirectory())
        fileListTextView.text = filelist?.description
        
        // dismiss keyboard
        view.endEditing(false)
    }
    
    // Save the text data and image to disk for each valid entry.
    //  Each entry must have an item name (not empty), cost (valid number),
    //  and an image.
    //
    // If all attributes are valid, save the text data with the ItemName.txt
    //  and the image to ItemName.jpg
    //
    //
    func saveDataToDisk() {
        
        
        // Get text data (title and cost)
        let itemTitle = itemTextField.text
        
        // First check if the title is valid (not an empty string), otherwise we can't make a file path
        if !itemTitle.isEmpty {
            
            // Use a number formatter to verify that we have a number value
            let numberFormatter = NSNumberFormatter()
            numberFormatter.numberStyle = NSNumberFormatterStyle.DecimalStyle  // CurrencyStyle requires $ to work, otherwise invalid input
            numberFormatter.minimumFractionDigits = 2
            
            var itemCost = numberFormatter.numberFromString(costTextField.text) as Double?
            
            if itemCost != nil {             // Valid cost input (number)
                // If itemCost is not nil, we have a valid number
                
                // save text data to disk as a string, construct the file path using the ItemTitle.txt
                let textPath = fileInDocumentsDirectory("\(itemTitle).txt")
                
                // Get image data
                let image = imageView.image
                
                if image != nil {
                    // There is a valid image, create a file path to save it in the documents folder as a .jpg file using the ItemTitle.jpg format.
                    
                    let imageFilename = "\(itemTitle).jpg"
                    let imagePath = fileInDocumentsDirectory(imageFilename)
                    
                    // Reuse the code you wrote in today's lesson
                    saveImage(image!, path: imagePath)
                    
                    // Create text to save out the data from the app to disk.
                    
                    // Use string interpolation to create a comma separated value string
                    var textDataToSave = "\(itemTitle), \(itemCost!), \(imageFilename)"
                    
                    // Save the string to disk
                    let status = saveText(textDataToSave, path: textPath)
                    println("Saved text data: \(status) to file \(textPath)")
                    
                } else { // Error messages can be useful to explain why you can't save
                    println("Error: item image is empty")
                }
                
            } else {
                println("Error: item cost is invalid: \(costTextField.text)")
            }
        } else {
            println("Missing item title")
        }
    }
    
    // Use the methods that you wrote from today's lessons
    
    func saveImage(image: UIImage, path: String) -> Bool {
        
        let jpgImageData = UIImageJPEGRepresentation(image, 1.0)
        // png UIImagePNG...
        let result = jpgImageData.writeToFile(path, atomically: true)
        return result
    }
    
    func loadImageFromPath(path: String) -> UIImage? {
        let image = UIImage(contentsOfFile: path)
        if image == nil {
            println("Missing image at path: \(path)")
        }
        
        return image
    }
    
    // Save text
    func saveText(text: String, path: String) -> Bool {
        var error: NSError? = nil
        let status = text.writeToFile(path, atomically: true, encoding: NSUTF8StringEncoding, error: &error)
        if !status { //status == false {
            println("Error saving file at path: \(path) with error: \(error?.localizedDescription)")
        }
        return status
    }
    
    // Load text
    func loadTextFromPath(path: String) -> String? {
        var error: NSError? = nil
        let text = String(contentsOfFile: path, encoding: NSUTF8StringEncoding, error: &error)
        if text == nil {
            println("Error loading text from path: \(path) error: \(error?.localizedDescription)")
        }
        return text
    }

    
    // Advanced 2: Return an array of filenames in the directory
    
    func directoryContents(path: String) -> [String]? {
        
        // Use the documents path to get a list of files
        var error: NSError? = nil
        var filenameArray = NSFileManager.defaultManager().contentsOfDirectoryAtPath(path, error: &error) as [String]?
        
        if filenameArray == nil {
            println("Error finding folder contents at path: \(filenameArray) error: \(error?.localizedDescription)")
        }
        return filenameArray
    }
    
    // Advanced 3: Make an array of only the .txt files
    
    func itemListFromDocumentDirectory() -> [String] {
        // Create a new array to store only .txt data file names
        var itemArray = [String]() // empty array
        
        let path = documentsDirectory()
        if let fileList = directoryContents(path) {
            // if we have files at the directory
            
            for item in fileList {
                if item.pathExtension == "txt" {
                    // add the .txt filename to the array
                    itemArray.append(item)
                }
            }
        }
        return itemArray
    }
    
    // Advanced 4: Remove all document files from the folder
    
    @IBAction func removeAllDocumentFiles(sender: AnyObject) {
        
        if let itemArray = directoryContents(documentsDirectory()) {
            for filename in itemArray {
                // remove file using full path
                
                let fullPath = fileInDocumentsDirectory(filename)
                
                var error: NSError? = nil
                let success = NSFileManager.defaultManager().removeItemAtPath(fullPath, error: &error)
                if !success {
                    println("Error removing file at path: \(fullPath) error: \(error?.localizedDescription)")
                } else {
                    println("Removed file: \(fullPath)")
                }
            }
            
        }
    }

    
    
}

