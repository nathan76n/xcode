//
//  ViewController.swift
//  myGuessingGame
//
//  Created by magicmiles on 10/14/14.
//  Copyright (c) 2014 magicmiles. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var myRandomNum = Int(arc4random_uniform(100)) + 1
    @IBOutlet weak var myGuessTextField: UITextField!
    @IBOutlet weak var myGuessLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        println("myNUM: \(myRandomNum)")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func myGuessButton(sender: AnyObject) {
        
        var myGuess = myGuessTextField.text.toInt()!
        
        if (myGuess == myRandomNum + 2) {
        
            myGuessLabel.text = "...cold..."
        
        } else if (myGuess == myRandomNum + 3) {
            
            myGuessLabel.text = "...colder..."
        
        } else if (myGuess == myRandomNum - 3) {
            
            myGuessLabel.text = "...warm..."
            
        } else if (myGuess == myRandomNum - 2) {
        
            myGuessLabel.text = "...getting warmer..."
            
        } else if (myGuess == myRandomNum + 1) || (myGuess == myRandomNum - 1) {
            
            myGuessLabel.text = " Really Close!"
                    
        } else if myGuess < myRandomNum {
            
            myGuessLabel.text = "Too Low"
            
        } else if myGuess > myRandomNum {
            
            myGuessLabel.text = "Too High"
        
        } else if myGuess == myRandomNum {
            
            myGuessLabel.text = "DING!"
        }
        
    }

    @IBAction func myGuessReset(sender: AnyObject) {
        
    }
}

