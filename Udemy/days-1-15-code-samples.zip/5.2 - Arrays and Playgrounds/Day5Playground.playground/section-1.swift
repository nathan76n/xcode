// Playground - noun: a place where people can play

import UIKit

// Arrays - lists

//var wordArray = [String]()

var wordArray = ["I", "like", "to", "eat", "fruit", "my", "favorite"]

wordArray[6]

wordArray.count

wordArray.first
wordArray.last


// Play with remove, add, and insert