//
//  ViewController.swift
//  SaveAndLoad
//
//  Created by Paul Solt on 10/27/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

// Documents Directory   /User/paulsolt/.../Documents/
func documentsDirectory() -> String {
    let documentsFolderPath = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0] as String
    return documentsFolderPath
}

func fileInDocumentsDirectory(filename: String) -> String {
    return documentsDirectory().stringByAppendingPathComponent(filename)
}

// File in Documents Directory   /User/paulsolt/.../Documents/Photo.jpg

class ViewController: UIViewController {

    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let documents = documentsDirectory()
        println("Documents: \(documents)")
        
        let imagePath = fileInDocumentsDirectory("Photo.jpg")
        println("Photo path: \(imagePath)")
        
        // Load image from Resource Bundle (read only)
        var image = UIImage(named: "Row.jpg")
        if image != nil {
            // Save it to our Documents folder
            println(image)
            
            let result = saveImage(image!, path: imagePath)
            println("saveImage: \(result)")
            
            // Load image
            var loadedImage = loadImageFromPath(imagePath) //"bad path")
            if loadedImage != nil {
                println("Image loaded: \(loadedImage!)")
                
                imageView.image = loadedImage
            }
        }
        
        // Text Loading and Saving
        
        saveText("Save Me!", path: fileInDocumentsDirectory("help.txt"))
    }
    
    func saveImage(image: UIImage, path: String) -> Bool {
        
        let jpgImageData = UIImageJPEGRepresentation(image, 1.0)
        // png UIImagePNG...
        let result = jpgImageData.writeToFile(path, atomically: true)
        return result
    }
    
    func loadImageFromPath(path: String) -> UIImage? {
        let image = UIImage(contentsOfFile: path)
        if image == nil {
            println("Missing image at path: \(path)")
        }
        
        return image
    }

    // Save text
    func saveText(text: String, path: String) -> Bool {
        var error: NSError? = nil
        let status = text.writeToFile(path, atomically: true, encoding: NSUTF8StringEncoding, error: &error)
        if !status { //status == false {
            println("Error saving file at path: \(path) with error: \(error?.localizedDescription)")
        }
        return status
    }
    
    
    // Load text
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

