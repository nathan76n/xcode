//
//  ViewController.swift
//  StopWatch
//
//  Created by Paul Solt on 10/16/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var timeLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    // Method Stubs
    func start() {
        
    }
    
    func stop() {
        
    }
    
    func reset() {
        
    }
    
    
    

    @IBAction func startButtonPressed(sender: AnyObject) {
        println("start")
        
        timeLabel.text = "Let's Go!"
        start()
    }
    @IBAction func stopButtonPressed(sender: AnyObject) {
        println("stop")
        stop()
    }
    
    @IBAction func resetButtonPressed(sender: AnyObject) {
        println("reset")
        reset()
    }


}

