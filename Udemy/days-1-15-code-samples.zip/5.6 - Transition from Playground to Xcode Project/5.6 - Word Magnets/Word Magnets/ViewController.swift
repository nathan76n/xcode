//
//  ViewController.swift
//  Word Magnets
//
//  Created by Paul Solt on 10/11/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        
        var wordArray = ["I", "like", "to", "eat", "fruit", "my", "favorite"]

        view.backgroundColor = UIColor.blackColor()
        
        for word in wordArray {
            
            var label = UILabel()
            label.text = word  // wordArray[4]
            label.font = UIFont.systemFontOfSize(32)
            
            label.sizeToFit()
            
            label.center = CGPoint(x: 150, y: 200)
            label.backgroundColor = UIColor.whiteColor()
            
            
            var x = CGFloat(arc4random_uniform(320))
            var y = CGFloat(arc4random_uniform(480))
            label.center = CGPoint(x: x, y: y)
            
            
            view.addSubview(label)
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

