//
//  ViewController.swift
//  Functions vs Methods
//
//  Created by Paul Solt on 10/14/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

// Functions


class ViewController: UIViewController {

    // Methods
    
    func changeBackgroundColor(color: UIColor) {
        view.backgroundColor = color
    }
    
    @IBAction func redButtonPressed(sender: AnyObject) {
        changeBackgroundColor(UIColor.redColor())
    }
    @IBAction func blueButtonPressed(sender: AnyObject) {
        changeBackgroundColor(UIColor.blueColor())
    }
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        changeBackgroundColor(UIColor.blueColor())
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

