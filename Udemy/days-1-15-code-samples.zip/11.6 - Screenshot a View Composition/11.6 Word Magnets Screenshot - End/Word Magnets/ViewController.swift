//
//  ViewController.swift
//  Word Magnets
//
//  Created by Paul Solt on 10/11/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBAction func screenshotPressed(sender: AnyObject) {
        println("screenshot")
        
        var image = takeScreenshot()
        
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }
    
    func takeScreenshot() -> UIImage {
        
        var theView = view
        
        UIGraphicsBeginImageContextWithOptions(theView.bounds.size, true, 0.0)
        
        theView.drawViewHierarchyInRect(theView.bounds, afterScreenUpdates: true)
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        return image
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Enable user interaction for the gestures as an imageView subview
        
        var wordArray = ["I", "like", "to", "eat", "fruit", "my", "favorite"]

        view.backgroundColor = UIColor.blackColor()
        
        for word in wordArray {
            
            var label = UILabel()
            label.text = word  // wordArray[4]
            label.font = UIFont.systemFontOfSize(32)
            
            label.sizeToFit()
            
            label.center = CGPoint(x: 150, y: 200)
            label.backgroundColor = UIColor.whiteColor()
            
            
            var x = CGFloat(arc4random_uniform(320))
            var y = CGFloat(arc4random_uniform(480))
            label.center = CGPoint(x: x, y: y)
            
            view.addSubview(label)
            
            // Pan Gesture
            var panGesture = UIPanGestureRecognizer(target: self, action: Selector("handlePanGesture:"))
            label.addGestureRecognizer(panGesture)
            label.userInteractionEnabled = true
            
            
        }
    }
    
    func handlePanGesture(panGesture: UIPanGestureRecognizer) {
        
        println("pan")
        
        // get translation
        var translation = panGesture.translationInView(view)
        panGesture.setTranslation(CGPointZero, inView: view)
        
        println(translation)
        
        // add dx, dy to current label center position
        
        var label = panGesture.view as UILabel
        label.center = CGPoint(x: label.center.x + translation.x,
            y: label.center.y + translation.y)
    }
   

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
}

