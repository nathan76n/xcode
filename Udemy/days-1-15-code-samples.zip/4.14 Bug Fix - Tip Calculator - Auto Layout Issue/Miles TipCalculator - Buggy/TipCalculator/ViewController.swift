//
//  ViewController.swift
//  TipCalculator
//
//  Created by magicmiles on 10/10/14.
//  Copyright (c) 2014 magicmiles. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    @IBOutlet weak var amountTextField: UITextField!
    @IBOutlet weak var tip10Label: UILabel!
    @IBOutlet weak var tip15Label: UILabel!
    @IBOutlet weak var tip20Label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func calcTipButtonPressed(sender: AnyObject) {
        
        // println("tip")
        
        if let amountCalcd = amountTextField.text {
        
            var tip10 = NSString(string: amountCalcd)
            var tip10Value = tip10.doubleValue
            var tip10Completed = tip10Value * 0.10
            tip10Label.text = "\(tip10Completed)"
            
            var tip15 = NSString(string: amountCalcd)
            var tip15Value = tip15.doubleValue
            var tip15Completed = tip15Value * 0.15
            tip15Label.text = "\(tip15Completed)"
            
            var tip20 = NSString(string: amountCalcd)
            var tip20Value = tip20.doubleValue
            var tip20Completed = tip20Value * 0.20
            tip20Label.text = "\(tip20Completed)"
            
        }
        
        
    }

}

