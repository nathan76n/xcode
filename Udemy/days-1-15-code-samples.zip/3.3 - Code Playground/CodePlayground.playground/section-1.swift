// Playground - noun: a place where people can play

import UIKit

var str = "Hi Paul!"
str

println("Hi Paul!")

var eyeColor = UIColor.blueColor()

for i in 1...20 {
    i
}

