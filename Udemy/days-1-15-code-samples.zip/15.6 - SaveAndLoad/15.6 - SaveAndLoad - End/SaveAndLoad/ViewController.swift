//
//  ViewController.swift
//  SaveAndLoad
//
//  Created by Paul Solt on 10/27/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

// Documents Directory   /User/paulsolt/.../Documents/
func documentsDirectory() -> String {
    let documentsFolderPath = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)[0] as String
    return documentsFolderPath
}

// File in Documents Directory   /User/paulsolt/.../Documents/Photo.jpg

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let documents = documentsDirectory()
        println("Documents: \(documents)")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

