// Playground - noun: a place where people can play

import UIKit

// if/else conditional statements

var isRaining = true

if isRaining {
    println("It's raining outside!")
    var x = 10
} else {
    println("It's sunny")
}


// Optionals

var businessAddress: String?

println(businessAddress)

businessAddress = "3902 Memorial Drive"

println(businessAddress)

if businessAddress != nil {
    println("Valid address, ship the package!")
}