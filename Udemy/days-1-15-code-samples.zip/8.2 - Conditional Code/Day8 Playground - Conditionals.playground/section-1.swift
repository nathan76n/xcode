// Playground - noun: a place where people can play

import UIKit

var isRaining = true

if isRaining {
    println("It's raining outside!")
    var x = 10
} else {
    println("It's sunny")
}
