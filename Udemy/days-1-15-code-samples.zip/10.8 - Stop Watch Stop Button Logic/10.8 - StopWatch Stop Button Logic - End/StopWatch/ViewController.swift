//
//  ViewController.swift
//  StopWatch
//
//  Created by Paul Solt on 10/16/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    // Instance variables
    var timer: NSTimer?
    
    var startTime: NSDate?
    var currentTime: NSDate?
    var stopTime: NSDate?
    
    @IBOutlet weak var timeLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    // Method Stubs
    func start() {
        startTime = NSDate()
        if timer == nil {
            timer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: Selector("updateTimer:"), userInfo: nil, repeats: true)
        }
    }
    
    func updateTimer(myTimer: NSTimer) {
//        println("timer... \(myTimer.timeInterval)")
        currentTime = NSDate()
        if startTime != nil {
            var duration = currentTime?.timeIntervalSinceDate(startTime!)
//            println("duration: \(duration)")
            timeLabel.text = duration?.description
        }
        
    }
    
    func stop() {
        stopTime = NSDate()
        
        // Stop the timer
        timer?.invalidate()
        timer = nil
    }
    
    func reset() {
        
    }
    
    
    
    @IBAction func startButtonPressed(sender: AnyObject) {
        println("start")
        
//        timeLabel.text = "Let's Go!"
        start()
    }
    @IBAction func stopButtonPressed(sender: AnyObject) {
        println("stop")
        stop()
    }
    
    @IBAction func resetButtonPressed(sender: AnyObject) {
        println("reset")
        reset()
    }


}

