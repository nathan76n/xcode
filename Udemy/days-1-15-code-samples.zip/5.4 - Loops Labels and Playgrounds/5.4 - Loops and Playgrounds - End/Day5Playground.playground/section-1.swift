// Playground - noun: a place where people can play

import UIKit
import XCPlayground

// Arrays - lists

//var wordArray = [String]()

var wordArray = ["I", "like", "to", "eat", "fruit", "my", "favorite"]

// Code in Playgrounds
wordArray[6]

wordArray.count

wordArray.first
wordArray.last
// ^ Code only in Playgrounds

// Play with remove, add, and insert



// Loops

//for word in wordArray {
////    println(word)
//    print("\(word), ")
//}
//
//for (index, word) in enumerate(wordArray) {
//    println("index[\(index)] = \(word)")
//}
//
//for var i = 0; i < 10; i++ {
//    println(i)
//}
//
//
//for i in 0...10 {
//    print(i)
//}

// interactive view

// Playgrounds Only Code
var view = UIView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))
view.backgroundColor = UIColor.orangeColor()

// Live Preview   #import XCPlayground
XCPShowView("Live Preview", view)
// Playgrounds Only Code ^


//view.backgroundColor = UIColor.blackColor()


// Create label (works on iPhone)

var label = UILabel()
label.text = wordArray[4]
label.font = UIFont.systemFontOfSize(32)

label.sizeToFit()

label.center = CGPoint(x: 150, y: 200)
label.backgroundColor = UIColor.whiteColor()

view.addSubview(label)


























