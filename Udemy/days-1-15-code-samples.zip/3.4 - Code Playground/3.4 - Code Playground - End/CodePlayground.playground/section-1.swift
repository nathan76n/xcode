// Playground - noun: a place where people can play

import UIKit

var str = "Hi Paul!"
str

println("Hi Paul!")

var eyeColor = UIColor.blueColor()

for i in 1...20 {
    i
}

// iPhone Screen (iPhone 3G)
//  You don't want to declare this variable in ViewController.swift
//  It's already declared in UIViewController's swift code file.
var view = UIView(frame: CGRect(x: 0, y: 0, width: 320, height: 480))

// lines of code that you can reuse in your iPhone app project
var image = UIImage(named: "Paul.jpg")
view.backgroundColor = eyeColor

var imageView = UIImageView(image: image)

view.addSubview(imageView)

var point = CGPoint(x: 320 / 2, y: 200)

imageView.center = point

// Show the view updated
view  // playground only to get quick look on the right ->