// Playground - noun: a place where people can play

import UIKit


// String and Character objects

let firstName = "Joe"
let lastName = "Smith"

//firstName = "David"

var fullName = firstName + lastName
fullName = firstName + " " + lastName
//fullName = firstName + " " + lastName + " Jr."

fullName = fullName + " Jr."

let letter1: Character = "C"
let letter2: Character = "E"

let comboLetter = letter1 + letter2




// Numbers


let pi = 3.14

let stairs = 2000
let stairsPerMinute = 60
let time = stairs / stairsPerMinute

let actualTime = Double(stairs) / Double(stairsPerMinute)
//let actualTime = stairs / Double(stairsPerMinute)

