//
//  ViewController.swift
//  Greeting App
//
//  Created by Paul Solt on 10/13/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var greetingLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func pressMeButtonPressed(sender: AnyObject) {
        
        // Insert code here
        
        var calendar = NSCalendar.currentCalendar()
        
        var timeDateComponents = calendar.components(
            NSCalendarUnit.HourCalendarUnit |
            NSCalendarUnit.MinuteCalendarUnit |
            NSCalendarUnit.SecondCalendarUnit, fromDate: NSDate())
        
        
        
        var hour = timeDateComponents.hour // the actual time, 8PM
        
        var name = "John"
        
        if hour >= 8 && hour < 12 {
            greetingLabel.text = "Good morning \(name)"
        } else if hour >= 12 && hour < (12 + 6) {
            greetingLabel.text = "Good afternoon \(name)"
        } else if hour >= (12 + 6) && hour < (12 + 10) {
            greetingLabel.text = "Good evening \(name)"
        } else {
            greetingLabel.text = "Enjoy your day!"
        }
        
        
        
        
        
    }


}

