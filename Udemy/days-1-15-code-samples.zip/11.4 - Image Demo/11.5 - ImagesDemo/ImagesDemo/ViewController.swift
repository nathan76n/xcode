//
//  ViewController.swift
//  ImagesDemo
//
//  Created by Paul Solt on 10/17/14.
//  Copyright (c) 2014 Paul Solt. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func imageButtonPressed(sender: AnyObject) {
        
        
        var imagePicker = UIImagePickerController()
        
        
        var sourceType = UIImagePickerControllerSourceType.SavedPhotosAlbum // Camera
        
        if UIImagePickerController.isSourceTypeAvailable(sourceType) {
            
            imagePicker.sourceType = sourceType
            
            imagePicker.delegate = self
            
            // show a screen
            
            presentViewController(imagePicker, animated: true, completion: nil)
        }
    }
    
    
    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [NSObject : AnyObject]) {
        
        
        
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    
    
    
    
    
    
    
    
    
    
    
}

