// Playground - noun: a place where people can play

import UIKit


// String and Character objects

let firstName = "Joe"
let lastName = "Smith"

//firstName = "David"

var fullName = firstName + lastName
fullName = firstName + " " + lastName
//fullName = firstName + " " + lastName + " Jr."

fullName = fullName + " Jr."

let letter1: Character = "C"
let letter2: Character = "E"

let comboLetter = letter1 + letter2
